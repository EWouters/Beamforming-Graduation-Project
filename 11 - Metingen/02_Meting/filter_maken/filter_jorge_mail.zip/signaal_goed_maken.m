close all;

load tsp.mat

%figure;plot(input);hold on;plot(output/max(output),'r');
aantal_nullen=round((1.640-1.605)*1e4-(1.6430-1.6380)*1e4+16+30-5);
output_padded=[zeros(aantal_nullen,1); output];
%figure;plot(input(1e4:1.5e4));hold on;plot(output_padded(1e4:1.5e4)/max(output_padded),'r');
%figure;plot(input);hold on;plot(output_padded/max(output_padded),'r');